cvLognormal <-function(var,...)sqrt(exp((var))-1)
cvNormal <- function(var,mean,...)sqrt(var)/mean
