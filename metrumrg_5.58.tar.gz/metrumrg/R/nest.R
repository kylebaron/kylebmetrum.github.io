`nest` <-
function(x,tag,...)c(bracket(tag),x,bracket(tag,close=TRUE))

