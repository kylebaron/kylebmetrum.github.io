glue <- function(...,sep='',collapse=NULL)paste(...,sep=sep,collapse=NULL)

