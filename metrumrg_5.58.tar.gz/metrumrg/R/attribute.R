`attribute` <-
function(x,tag,...)glue(' ',tag,"='",x,"'")

